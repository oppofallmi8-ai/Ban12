---
title: "Potato sourdough bread"
date: 2021-03-23
tags: ['sourdough', 'bread', 'potato']
author: "SirStart"
---

![Potato sourdough bread](/pix/sourdough-potato-bread.webp)

- ⏲️ Prep time: 15 min
- 🍳 Cook time: 45 min

## Ingredients

- 150g boiled potatoes in there skin
- 350g wheat flour
- 50g whole rye flour
- 11g salt
- 150g water
- 250g sourdough

## Directions

1. Boil the potatoes
2. Peel of the skin of the potatoes (let them cool down a bit)
3. Stir all ingredients and knead them well.
4. Let the dough rest for 5 hours in warm (25-30°C) conditions.
5. Preheat the oven to 250°C.
6. Bake for up to 10 minute with steam.
7. Release the steam and turn the heat down to 220°C.
8. Bake for another 35 minutes
