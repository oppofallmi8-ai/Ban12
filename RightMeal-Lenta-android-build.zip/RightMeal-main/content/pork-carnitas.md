---
title: "Slow-cooked Pork Carnitas"
date: 2021-03-21
tags: ['pork', 'slowcooked', 'mexican']
author: "sam"
---

This recipe makes a lot and is super easy. A whole roast usually makes enough for a few meals (depending on how many people will be eating it). Leftovers can be refrigerated for 4-5 days.

- ⏲️ Prep time: 15 min
- 🍳 Cook time: 8 hr 30 min
- 🍽️ Servings: 10-11

## Ingredients

- 2 ½ lbs. boneless pork shoulder
- 6 cloves of garlic, cut into slivers
- 1 ½ teaspoons cumin
- ½ teaspoon sazon
- ¼ teaspoon dry oregano
- ¾ cup low sodium chicken broth
- 2-3 chipotle peppers in adobo sauce
- 2 bay leaves
- ¼ teaspoon dry adobo seasoning

## Directions

1. Season pork with kosher salt and pepper.
2. In a medium sauté pan on medium-high heat, brown pork on all sides.
3. Remove from heat and allow to cool, about 10 minutes.
4. Using a sharp knife, insert blade into pork, cutting small holes and insert garlic slivers as far in as you can.
5. Pour chicken broth in slow cooker.
6. Add pork and season with cumin, adobo, sazon, and oregano.
7. Add bay leaves and chipotle peppers.
8. Cover and cook low for 8 hours.
9. After 8 hours, shred pork using 2 forks and combine with juices.
10. Let cook for another 15-30 mins.
