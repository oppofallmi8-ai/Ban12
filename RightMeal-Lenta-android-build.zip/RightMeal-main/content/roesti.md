---
title: "Rösti"
date: 2021-03-12
tags: ['swiss', 'potato', 'side', 'cheesefare']
author: elias-pahls
---

![Rösti](/pix/roesti.webp)
Used two serving sizes for this Rösti

This swiss classic works great together with fried eggs and steamed peas or spinach.
Can be useful to get rid of leftover potatoes from the day before.

- ⏲️ Prep time: 20 min
- 🍳 Cook time: 20 min
- 🍽️ Servings: 4

## Ingredients

- ~800g (~1.5lb) potatoes (firm/waxy)
- 2 carrots
- 500g (~1lb) peas or spinach
- 4 eggs
- 2 onions (medium size)
- butter

## Directions

2. Shred raw or cooked (but cool) potatoes with a grater. The shreds should be
   quite large so don't use your typical cheese shredder.
3. Dice the first onion and mix together with potatoes. You can also add diced
   bacon if you want to. Add your seasonings here.
4. Heat up some butter in a large pan. Add your mix to the pan on high heat.
   Let the mixture get warm for a few minutes under constant stirring.
5. Reduce heat to medium-high. Form the Rösti into a round cack. It should fill
   out the whole pan. I recommend a thickness of around 1 - 1.5cm (~1/2") for a
   softer Rösti.
6. Add some more butter flakes around the inside of the pan to get it under the
   Rösti.
7. It can take quite a while for a nice crust to form. Check after roughly 5-10
   minutes for browning.
8. While the Rösti is cooking dice the other onion and the carrots. Steam
   everything in a pan with a bit of water. Use a lid to get the temperature
   up.
9. Alternatively you can use fresh or creamed spinach.
10. When you're satisfied with the browning, flip the Rösti and set the heat to
    medium-low. A plate can be useful here, put it on top of the Rösti in the
    pan and flip. Then gently put the whole cake back in the pan.
11. When the Rösti crispness is to your liking, remove from pan and fry two
    eggs. A runny yolk adds quite a bit to the potatoes.
12. Top Rösti with eggs and serve with the peas or spinach.
