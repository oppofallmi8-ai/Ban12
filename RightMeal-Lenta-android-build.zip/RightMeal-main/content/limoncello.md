---
title: "Limoncello"
date: 2021-05-13
tags: ['alcohol', 'lemon', 'digestivo', 'liquor']
author: mfed3
---

![Limoncello](/pix/limoncello.webp)

- ⏲️ Prep time: 10 min
- 🍳Wait time: 20 days
- 🍽️ Servings: 22

## Ingredients

- 5-7 organic lemons (regular lemons are covered in wax)
- 300ml 95% ABV grain alcohol
- 700ml water
- 500ml sugar

## Directions

1. Pour the alcohol into a 1 liter mason jar
2. Peel the lemons avoiding the white pith (it will make your limoncello bitter) and submerse them in the alcohol
3. Cover the jar and let the lemons infuse the alcohol for 20 days
4. After the infusion is completed, create a simple syrup by boiling the water and dissolving the sugar in the water
5. Allow the water to cool completely, then strain the alcohol into the sugar water and stir
6. Bottle or put it back into the mason jar
7. Feel free to scale the recipe up or down, and adjust the sugar to the sweetness you like, but the ABV should remain somewhere around 28-30%
