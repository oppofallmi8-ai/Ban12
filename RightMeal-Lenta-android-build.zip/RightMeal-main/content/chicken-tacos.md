---
title: "Slow-cooked Chicken Tacos"
date: 2021-03-10
tags: ['mexican', 'chicken', 'slowcooked']
author: luke-smith
---

## Ingredients

- chicken breasts
- two or three onions (preferably red)
- seasoning:
	- adobo seasoning
	- paprika
- cheese (either shredded Mexican blend or crumbling cheese)
- small tortillas
- lime
- cilantro, tomato, lettuce, other desired taco contents

## Directions

1. Quarter two onions and spread on the bottom of a slow-cooker.
2. Place chicken breasts on top of onions.
3. Season slow-cooker contents liberally with adobo seasoning, paprika and any other desired seasonings, squeeze half of a lime too if desired.
4. Let cook on low for 8 hours. Cooking on high for less time is possible as well, but a slower cook is preferable.
7. Dice the tomato, cilantro, any lettuce and the third onion for taco contents.
9. Shred chicken with forks once cooked. Optionally add a dash more seasoning for taste or appearance.
10. Add chicken, cheese and all the diced ingredients to tortillas.
11. Squeeze remainder of lime over finished product.
