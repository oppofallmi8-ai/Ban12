"""Lenta Integration API provider for Russian retail pickup prices.

Uses the public read-only Integration API. The selected store is configured by
LENTA_STORE_ID; pickup is requested first with channel ``cc`` and ``locc`` is a
compatibility fallback for the Lenta Online pickup channel.
"""
from __future__ import annotations

import os
import re
from typing import Any

import httpx

from models.food import Food
from models.pricing import Location, PriceQuote, PriceSource
from services.matching import _normalize, _tokens
from services.price_providers.base import REQUEST_TIMEOUT_SECONDS, PriceProvider, ProviderResult, now_iso
from services.units import normalized_price

BASE_URL = "https://integration.api.lenta.com/catalog/v1/items"

# Russian catalog queries for the curated food IDs. These are search hints, not
# product identities; results still have to pass a deterministic name match.
RU_TERMS: dict[str, tuple[str, ...]] = {
    "brown_rice": ("бурый рис", "рис нешлифованный"),
    "rice_white": ("рис белый", "рис длиннозерный"),
    "rolled_oats": ("овсяные хлопья", "геркулес"),
    "bread_whole_wheat": ("цельнозерновой хлеб", "хлеб зерновой"),
    "spaghetti_dry": ("спагетти", "макароны"),
    "tortillas_flour": ("пшеничные тортильи", "лепешки тортилья"),
    "potatoes_russet": ("картофель", "картошка"),
    "eggs_large": ("яйца куриные", "яйцо куриное"),
    "chicken_breast": ("куриное филе", "филе грудки курицы"),
    "ground_beef": ("фарш говяжий", "говяжий фарш"),
    "canned_tuna": ("тунец консервированный", "тунец в собственном соку"),
    "black_beans_dry": ("черная фасоль сухая", "фасоль черная"),
    "lentils_dry": ("чечевица сухая", "чечевица"),
    "chickpeas_canned": ("нут консервированный", "нут"),
    "peanut_butter": ("арахисовая паста",),
    "tofu_firm": ("тофу", "сыр тофу"),
    "carrots": ("морковь",), "onions_yellow": ("лук репчатый", "лук желтый"),
    "cabbage_green": ("капуста белокочанная", "капуста"),
    "spinach_fresh": ("шпинат свежий", "шпинат"),
    "broccoli_frozen": ("брокколи замороженная", "брокколи"),
    "mixed_veg_frozen": ("овощная смесь замороженная", "смесь овощей"),
    "tomatoes_canned": ("томаты резаные консервированные", "помидоры в собственном соку"),
    "bananas": ("бананы",), "apples_gala": ("яблоки", "яблоки красные"),
    "oranges_navel": ("апельсины",), "berries_frozen": ("ягоды замороженные", "смесь ягод"),
    "raisins": ("изюм",), "milk_whole": ("молоко цельное", "молоко 3.2"),
    "yogurt_plain": ("йогурт натуральный", "йогурт без добавок"),
    "cheddar_cheese": ("сыр чеддер", "чеддер"), "soy_milk_fortified": ("соевое молоко",),
    "canola_oil": ("масло растительное", "рапсовое масло"), "olive_oil": ("масло оливковое",),
    "avocados": ("авокадо",), "chicken_thighs": ("бедро куриное филе", "филе бедра курицы"),
    "ground_turkey": ("фарш индейки", "индейка фарш"), "pork_chops": ("свиная корейка", "свиные отбивные"),
    "beef_sirloin_steak": ("стейк говяжий", "говядина стейк"), "salmon_fillet": ("филе лосося", "лосось филе"),
    "shrimp": ("креветки очищенные", "креветки"), "tilapia_fillet": ("филе тилапии", "тилапия"),
    "canned_salmon": ("горбуша консервированная", "лосось консервированный"),
    "deli_turkey_breast": ("ветчина из индейки", "индейка нарезка"),
    "bell_peppers": ("перец сладкий", "перец болгарский"), "peas_frozen": ("горошек зеленый замороженный", "зеленый горошек"),
    "sweet_potatoes": ("батат",), "grapes": ("виноград",), "peaches_canned": ("персики консервированные", "персики в сиропе"),
    "cottage_cheese": ("творог 5%", "творог"), "almonds": ("миндаль",), "quinoa_dry": ("киноа",),
    "tortillas_corn": ("кукурузные тортильи",), "bacon": ("бекон",), "butter": ("масло сливочное",),
    "chicken_broth": ("куриный бульон",), "flour_all_purpose": ("мука пшеничная",),
    "green_onions": ("лук зеленый",), "heavy_cream": ("сливки  жирные", "сливки 33"),
    "honey": ("мед", "мёд"), "lemon": ("лимон",), "lime": ("лайм",),
    "mozzarella_cheese": ("моцарелла",), "mushrooms": ("шампиньоны",),
    "parmesan_cheese": ("пармезан",), "sausage": ("колбаса", "сосиски"),
    "sour_cream": ("сметана",), "soy_sauce": ("соевый соус",), "sugar_white": ("сахар",),
    "tomato_paste": ("томатная паста",), "tomato_sauce": ("томатный соус",), "tomatoes_fresh": ("помидоры", "томаты свежие"),
}


def _as_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if value > 0 else None
    if isinstance(value, str):
        cleaned = value.replace("\u00a0", " ").replace(" ", "").replace(",", ".")
        match = re.search(r"\d+(?:\.\d+)?", cleaned)
        if match:
            try:
                number = float(match.group())
                return number if number > 0 else None
            except ValueError:
                return None
    if isinstance(value, dict):
        for key in ("current", "value", "amount", "price", "regular", "regularPrice", "price_num"):
            if key in value:
                number = _as_number(value[key])
                if number is not None:
                    return number
    return None


def _product_name(item: dict[str, Any]) -> str:
    for key in ("name", "title", "productName", "description", "displayName"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _product_price(item: dict[str, Any]) -> float | None:
    # Prefer current/promo price when available, then regular price.
    for key in ("price_num", "discountPrice", "promoPrice", "pricePromo", "price", "currentPrice", "regular_price", "regularPrice", "priceRegular"):
        if key in item:
            value = _as_number(item[key])
            if value is not None:
                return value
    return None


def _products(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("items", "products", "data", "results", "content"):
        value = payload.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]
        if isinstance(value, dict):
            nested = _products(value)
            if nested:
                return nested
    return []


def _match_score(terms: tuple[str, ...], name: str) -> float:
    product_tokens = _tokens(name)
    best = 0.0
    for term in terms:
        term_tokens = _tokens(term)
        if not term_tokens:
            continue
        overlap = len(term_tokens & product_tokens) / len(term_tokens)
        normalized_term = _normalize(term)
        normalized_name = _normalize(name)
        # Token coverage is more robust than whole-title similarity for branded
        # supermarket listings, while still requiring actual name overlap.
        from difflib import SequenceMatcher
        ratio = SequenceMatcher(None, normalized_term, normalized_name).ratio()
        best = max(best, 0.7 * overlap + 0.3 * ratio)
    return round(best, 4)


class LentaProvider(PriceProvider):
    name = "lenta"
    source = PriceSource.LENTA_REAL_PRICE

    def __init__(self, store_id: str | None, http_client: httpx.AsyncClient):
        self._store_id = (store_id or os.getenv("LENTA_STORE_ID", "")).strip()
        self._client = http_client

    def is_configured(self) -> bool:
        return bool(self._store_id)

    async def _search(self, term: str, channel: str) -> list[dict[str, Any]]:
        response = await self._client.get(
            BASE_URL,
            params={
                "stores": self._store_id,
                "channel": channel,
                "query": term,
                "retailBrand": "lo",
                "limit": 10,
                "offset": 0,
            },
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        return _products(response.json())

    async def get_quote(self, food: Food, location: Location) -> ProviderResult:
        terms = RU_TERMS.get(food.id, (food.name,))
        errors: list[str] = []
        candidates: list[tuple[float, dict[str, Any], float, tuple[float, str]]] = []
        # cc is the documented Click & Collect channel; locc is the separate
        # Lenta Online pickup channel. Try the latter if cc is unavailable.
        for channel in ("cc", "locc"):
            for term in terms:
                try:
                    items = await self._search(term, channel)
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{channel}/{term}: {type(exc).__name__}: {exc}")
                    # A server/channel failure is unlikely to be query-specific;
                    # switch channels instead of hammering the failing endpoint.
                    break
                for item in items:
                    name = _product_name(item)
                    price = _product_price(item)
                    if not name or price is None:
                        continue
                    # Most catalog listings include the package size in their name.
                    # A few expose it as weight/volume; append it for unit parsing.
                    size_hint = item.get("weight") or item.get("volume") or item.get("size") or ""
                    size_text = f"{name} {size_hint}".strip()
                    normalized = normalized_price(price, size_text, food)
                    if normalized is None:
                        continue
                    score = _match_score(terms, name)
                    candidates.append((score, item, price, normalized))
                if candidates:
                    break
            if candidates:
                break
        if not candidates:
            detail = "; ".join(errors) if errors else "no matching product with a parseable package size and price"
            return self.failure(detail)

        confidence, item, price, (per_100, normalized_unit) = max(
            candidates, key=lambda row: (row[0], _product_name(row[1]).casefold())
        )
        if confidence < 0.65:
            return self.failure(f"best product match confidence {confidence:.2f} is below 0.65")
        name = _product_name(item)
        size = str(item.get("weight") or item.get("volume") or item.get("size") or name)
        return self.result(PriceQuote(
            food_name=food.name,
            matched_product_name=name,
            price=price,
            unit=size,
            unit_price=price,
            normalized_unit_price=per_100,
            raw_unit=size,
            normalized_unit=normalized_unit,
            store=f"Лента (магазин {self._store_id}, самовывоз)",
            source=self.source,
            confidence=confidence,
            is_estimate=False,
            last_updated=now_iso(),
            match_reason=f"товар найден в каталоге «Ленты» для самовывоза: {name}; совпадение {confidence:.2f}",
        ))
