"""Pure and UI-level thumbnail selection for meals and prepared leftovers."""

from types import SimpleNamespace

from models.prepared_leftover import PreparedFoodPortion, PreparedLeftover
from services.meal_presentation import (
    representative_food_for_leftover,
    representative_recipe_id_for_leftover,
)
from ui.meals_section import prepared_leftover_photo


def make_leftover(portions) -> PreparedLeftover:
    return PreparedLeftover(
        id="leftover-1",
        origin_kind="user",
        source_date="2026-07-22",
        source_slot="breakfast",
        source_meal_template_id="",
        meal_name="Hearty Breakfast Oatmeal",
        note="",
        initial_fraction_remaining=0.5,
        servings_remaining=0.5,
        portions=list(portions),
    )


def test_leftover_photo_prefers_source_recipe_and_solid_fallback(foods_by_id):
    leftover = make_leftover([
        PreparedFoodPortion(
            "milk_whole", "Whole milk", 200.0, 100.0,
            component_kind="main", source_recipe_id="oatmeal-recipe",
        ),
        PreparedFoodPortion(
            "rolled_oats", "Rolled oats", 80.0, 40.0,
            component_kind="main", source_recipe_id="oatmeal-recipe",
        ),
    ])

    class StubState:
        recipes_by_id = {
            "oatmeal-recipe": SimpleNamespace(
                image_asset="recipe_images/hearty-breakfast-oatmeal.webp"
            )
        }

        def __init__(self):
            self.foods_by_id = foods_by_id

        @staticmethod
        def image_src_for(food):
            return f"food:{food.id}"

    photo = prepared_leftover_photo(leftover, StubState(), size=110, width=276)

    assert photo.content.src == "/recipe_images/hearty-breakfast-oatmeal.webp"
    fallback = photo.content.error_content
    assert fallback.content.src == "food:rolled_oats"


def test_leftover_without_dish_image_does_not_use_heavier_liquid(foods_by_id):
    leftover = make_leftover([
        PreparedFoodPortion("milk_whole", "Whole milk", 200.0, 100.0),
        PreparedFoodPortion("rolled_oats", "Rolled oats", 80.0, 40.0),
    ])

    assert representative_food_for_leftover(leftover, foods_by_id).id == "rolled_oats"


def test_leftover_recipe_prefers_live_main_but_uses_side_when_main_is_gone():
    main = PreparedFoodPortion(
        "main", "Main", 100.0, 30.0,
        component_kind="main", source_recipe_id="main-recipe",
    )
    side = PreparedFoodPortion(
        "side", "Side", 300.0, 200.0,
        component_kind="side", source_recipe_id="side-recipe",
    )
    leftover = make_leftover([main, side])

    assert representative_recipe_id_for_leftover(leftover) == "main-recipe"
    main.remaining_grams = 0.0
    assert representative_recipe_id_for_leftover(leftover) == "side-recipe"
